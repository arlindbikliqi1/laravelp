## Reporting a Vulnerability

If you discover any security related issues, please email security@monicahq.com instead of using the issue tracker.
