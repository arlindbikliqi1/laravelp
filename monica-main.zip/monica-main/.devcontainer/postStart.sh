#!/bin/bash

sudo apache2ctl restart
