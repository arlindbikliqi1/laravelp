<?php

namespace App\Domains\Contact\DavClient\Services\Utils\Dav;

use Exception;

class DavClientException extends Exception {}
