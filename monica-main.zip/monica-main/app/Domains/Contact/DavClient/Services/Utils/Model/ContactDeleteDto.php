<?php

namespace App\Domains\Contact\DavClient\Services\Utils\Model;

class ContactDeleteDto extends ContactDto {}
