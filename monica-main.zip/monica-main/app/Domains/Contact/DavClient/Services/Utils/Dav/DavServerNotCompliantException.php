<?php

namespace App\Domains\Contact\DavClient\Services\Utils\Dav;

class DavServerNotCompliantException extends DavClientException {}
