<?php

namespace App\Domains\Contact\Dav;

interface ImportResource {}
